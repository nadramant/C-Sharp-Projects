==========================Exercise Checking Report==========================
Exercise No...........: 1
First Student Details.: 313453284 - Aviv Zafrani
Second Student Details: 318421534 - Yael Davidov
Delivery Date.........: 29/04/2020
Delivered In Delay....: No
Delay Reason..........: -
Visual Studio Version.: 2017
Comments..............: -
=======================End Exercise Checking Report=========================