﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class Car 
    {
        private enum eColor
        {
            Red,
            White,
            Black,
            Silver
        }
        private int m_NumOfDoors;
    }
}
