﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class ElectricEngine : Engine
    {
        private float RemainingBatteryTime;
        private float MaxBatteryTime;

        public void BatteryCharging(int i_TimeToAddToBattery)
        {

        }
    }
}
