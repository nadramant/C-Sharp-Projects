﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    abstract class Vehicle
    {
        private string m_ModelName;
        private string m_LicenseNumber;
        private float m_PercentOfEnergyRemaining;
        private Engine m_Engine;
        private List<Wheel> m_Wheels;
    }
}
