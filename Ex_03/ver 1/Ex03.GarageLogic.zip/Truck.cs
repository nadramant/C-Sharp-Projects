﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class Truck : Vehicle
    {
        private bool m_TransportHazardousMaterials; 
        private float m_CargoCapacity; 


    }
}
