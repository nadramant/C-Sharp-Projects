﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricCar : Car
    {
        protected const float k_MaxBatteryTime = 2.1f;
        private ElectricEngine m_Engine;

        public ElectricCar(string i_Lisence) : base(i_Lisence)
        {
            m_Engine = new ElectricEngine(k_MaxBatteryTime);
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = base.BuildVehicleInputsList();
            ElectricEngine.updateVehicleInputsList(vehicleInputsList);

            return vehicleInputsList;
        }

        public ElectricEngine ElectricEngine
        {
            get
            {
                return this.m_Engine;
            }
            set
            {
                this.m_Engine = value;
            }
        }

        public void SetEngine(string i_RemainingBatteryTime)
        {
            float remainingBatteryTime;

            if (float.TryParse(i_RemainingBatteryTime, out remainingBatteryTime) == false)
            {
                throw new FormatException("You must enter a number which represent the remaining bettary time.");
            }

            if (!(0 <= remainingBatteryTime && remainingBatteryTime <= m_Engine.MaxBatteryTime))
            {
                throw new ValueOutOfRangeException(0, m_Engine.MaxBatteryTime);
            }

            m_Engine.RemainingBatteryTime = remainingBatteryTime;

            this.PercentageOfRemainingEnergy = (m_Engine.RemainingBatteryTime / m_Engine.MaxBatteryTime) * 100;
        }// שיכפול קוד, לחשוב על פתרון
    }
}
