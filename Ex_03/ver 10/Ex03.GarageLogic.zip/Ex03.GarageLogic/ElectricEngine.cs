﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricEngine
    {
        private float m_RemainingBatteryTime;
        private readonly float r_MaxBatteryTime;

        public ElectricEngine(float i_MaxBatteryTime)
        {
            r_MaxBatteryTime = i_MaxBatteryTime;
        }

        public void BatteryCharging(int i_TimeToAddToBattery)
        {

        }

        public static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("the remaining battery time in hourse:");
            //vehicleInputsList.Add("max battery time"); //לא צריך את זה
        }

        public float MaxBatteryTime
        {
            get
            {
                return r_MaxBatteryTime;
            }
        }

        public float RemainingBatteryTime
        {
            set
            {
                m_RemainingBatteryTime = value;
            }
            get
            {
                return m_RemainingBatteryTime;
            }
        }


    }
}
