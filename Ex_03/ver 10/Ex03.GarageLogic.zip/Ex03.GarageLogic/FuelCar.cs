﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelCar : Car
    {
        FuelEngine m_Engine;
        protected const FuelEngine.eFuelType k_FuelType = FuelEngine.eFuelType.Octan96;
        protected const float k_MaximumAmountOfFuel = 60;

        public FuelCar(string i_Lisence) : base(i_Lisence)
        {
            m_Engine = new FuelEngine(k_MaximumAmountOfFuel, k_FuelType);
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleDictionary = base.BuildVehicleInputsList();
            FuelEngine.updateVehicleInputsList(vehicleDictionary);

            return vehicleDictionary;
        }

        public void SetEngine(string i_RemainingAmountOfFuel)
        {
            float remainingAmountOfFuel;

            if (float.TryParse(i_RemainingAmountOfFuel, out remainingAmountOfFuel) == false)
            {
                throw new FormatException("You must enter a number to the current amount of fuel.");
            }

            if (!(0 <= remainingAmountOfFuel && remainingAmountOfFuel <= m_Engine.MaximumAmountOfFuel))
            {
                throw new ValueOutOfRangeException(0, m_Engine.MaximumAmountOfFuel);
            }

            m_Engine.RemainingAmountOfFuel = remainingAmountOfFuel;

            this.PercentageOfRemainingEnergy = (m_Engine.RemainingAmountOfFuel / m_Engine.MaximumAmountOfFuel)*100;
        }// שיכפול קוד, לחשוב על פתרון
    }
}
