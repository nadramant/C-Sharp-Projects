﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelEngine
    {
        public enum eFuelType
        {
            Octan98,
            Octan96,
            Octan95,
            Soler
        }

        private readonly eFuelType r_FuelType;
        private float m_RemainingAmountOfFuel;
        private readonly float r_MaximumAmountOfFuel;

        public FuelEngine(float i_MaximumAmountOfFuel, eFuelType i_FuelType)
        {
            r_FuelType = i_FuelType;
            r_MaximumAmountOfFuel = i_MaximumAmountOfFuel;
        }

        public void Refuling(float i_AmountOfFuelToAdd, eFuelType i_FuelType)
        {

        }

        internal static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("the current amount of fuel:");
        }

        public float RemainingAmountOfFuel
        {
            set
            {
                m_RemainingAmountOfFuel = value;
            }
            get
            {
                return m_RemainingAmountOfFuel;
            }
        }

        public float MaximumAmountOfFuel
        {
            get
            {
                return r_MaximumAmountOfFuel;
            }
        }
    }
}
