﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        public enum eCarDetails
        {
            NameOfOwner, PhoneNumberOfOwner, CarStatusInGarage
        }

        public enum eCarStatusInGarage
        {
            InRepair = 1, Repaired, Paied
        }

        public Dictionary<Vehicle, object[]> m_VehiclesInGarage = new Dictionary<Vehicle, object[]>(); // change to private

        public object[] this[Vehicle vehicle]
        {
            get
            {
                return m_VehiclesInGarage[vehicle];
            }

            set
            {
                m_VehiclesInGarage[vehicle] = value;
            }
        }

        public object this[Vehicle vehicle, eCarDetails details]
        {
            get
            {
                return m_VehiclesInGarage[vehicle][(int)details];
            }
            set
            {
                m_VehiclesInGarage[vehicle][(int)details] = value;
            }
        }

        public void RangeOfCarStatusInGarge(out int o_MinVal, out int o_MaxVal)
        {
            o_MinVal = (int)eCarStatusInGarage.InRepair;
            o_MaxVal = (int)eCarStatusInGarage.Paied;
        }

        public void IsVehicleInGarge(string i_VehicleLicenseNum, out Vehicle o_FoundVehicle)
        {
            if(!(IsVehicleExistInGarage(i_VehicleLicenseNum, out o_FoundVehicle)))
            {
                throw new Exception("The veicle does not exist in the garage");
            }

        }

        public bool IsVehicleExistInGarage(string i_VehicleLicenseNum, out Vehicle o_FoundVehicle)
        {
            bool isVehicleExist = false;
            o_FoundVehicle = null;

            if (m_VehiclesInGarage.Count != 0)
            {
                foreach (KeyValuePair<Vehicle, object[]> currPair in m_VehiclesInGarage)
                {
                    if (i_VehicleLicenseNum.GetHashCode() == currPair.Key.GetHashCode())
                    {
                        isVehicleExist = true;
                        o_FoundVehicle = currPair.Key;
                    }
                }
            }

            return isVehicleExist;
        }

        public void AddCarToGarage(Vehicle i_VehicleToAdd, string i_NameOfOwner, string i_PhoneNumberOfOwner)
        {
            foreach (char ch in i_NameOfOwner)
            {
                if (!(char.IsLetter(ch) || Char.IsWhiteSpace(ch)))
                {
                    throw new FormatException("Name of owner must contain only letters and spaces.");
                }
            }

            foreach (char ch in i_PhoneNumberOfOwner)
            {
                if (!(char.IsDigit(ch)))
                {
                    throw new FormatException("Phone number must contain only digits.");
                }
            }

            m_VehiclesInGarage.Add(i_VehicleToAdd,new object[] { i_NameOfOwner, i_PhoneNumberOfOwner, eCarStatusInGarage.InRepair});
        }

        public List<string> AllVehiclesInGarage(eCarStatusInGarage i_VehicleStatus)
        {
            List<string> lisencesInGarageList = new List<string>();

            if(!(Enum.IsDefined(typeof(eCarStatusInGarage),i_VehicleStatus)))
            {
                foreach (KeyValuePair<Vehicle, object[]> currPair in m_VehiclesInGarage)
                {
                    lisencesInGarageList.Add(currPair.Key.LicenseNumber);
                }
            }
            else
            {
                foreach (KeyValuePair<Vehicle, object[]> currPair in m_VehiclesInGarage)
                {
                    if ((eCarStatusInGarage)currPair.Value[(int)eCarDetails.CarStatusInGarage] == (eCarStatusInGarage)i_VehicleStatus)
                    {
                        lisencesInGarageList.Add(currPair.Key.LicenseNumber);
                    }
                }
            }
            return lisencesInGarageList;
        }

        public void ChangeVehicleStatusInGarage(Vehicle i_VehicleToChange, Garage.eCarStatusInGarage i_NewStatus)
        {
            (m_VehiclesInGarage[i_VehicleToChange])[(int)eCarDetails.CarStatusInGarage] = i_NewStatus;
        }
    }
}
