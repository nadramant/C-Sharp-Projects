﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class Truck : Vehicle
    {
        protected const int k_NumOfWheels = 16;
        protected const int k_MaxAirPressure = 28;
        protected const FuelEngine.eFuelType k_FuelType = FuelEngine.eFuelType.Soler;
        protected const float k_MaximumAmountOfFuel = 120;
        private bool m_TransportHazardousMaterials; 
        private float m_CargoCapacity;
        FuelEngine m_Engine;

        public Truck(string i_Lisence) : base(i_Lisence, k_NumOfWheels, k_MaxAirPressure)
        {
            m_Engine = new FuelEngine(k_MaximumAmountOfFuel, k_FuelType);
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = base.BuildVehicleInputsList();

            vehicleInputsList.Add("1 if it transport hazardous materials. else, enter 2.");
            vehicleInputsList.Add("the cargo capacity of the truck");
            FuelEngine.updateVehicleInputsList(vehicleInputsList);

            return vehicleInputsList;
        }

        public void SetEngine(string i_RemainingAmountOfFuel)
        {
            float remainingAmountOfFuel;

            if (float.TryParse(i_RemainingAmountOfFuel, out remainingAmountOfFuel) == false)
            {
                throw new FormatException("You must enter a number to the current amount of fuel.");
            }

            if (!(0 <= remainingAmountOfFuel && remainingAmountOfFuel <= m_Engine.MaximumAmountOfFuel))
            {
                throw new ValueOutOfRangeException(0, m_Engine.MaximumAmountOfFuel);
            }

            m_Engine.RemainingAmountOfFuel = remainingAmountOfFuel;

            this.PercentageOfRemainingEnergy = (m_Engine.RemainingAmountOfFuel / m_Engine.MaximumAmountOfFuel) * 100;
        }// שיכפול קוד, לחשוב על פתרון

        public void SetCargoCapacity(string i_CargoCapacity)
        {
            float cargoCapacity;

            if (float.TryParse(i_CargoCapacity, out cargoCapacity) == false)
            {
                throw new FormatException("You must enter a number to the cargo capacity.");
            }

            if (cargoCapacity < 0)
            {
                throw new ArgumentException("cargo's capacity can not be negative.");
            }

            m_CargoCapacity = cargoCapacity;
        }

        public void SetTransportHazardousMaterials(string i_IsTransportHazardousMaterials)
        {
            int isTransportHazardousMaterials;

            if (int.TryParse(i_IsTransportHazardousMaterials, out isTransportHazardousMaterials) == false)
            {
                throw new FormatException("Invalid input - You must write an integer number.");
            }

            if (isTransportHazardousMaterials == 1)
            {
                m_TransportHazardousMaterials = true;
            }
            else if (isTransportHazardousMaterials == 2)
            {
                m_TransportHazardousMaterials = false;
            }
            else
            {
                throw new ArgumentException("Invalid input - wrong choice. You must enter 1 if it transport hazardous materials. else, 2.");
            }
        }


    }
}
