﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricCar : Car
    {
        protected const float k_MaxBatteryTime = 2.1f;
        private ElectricEngine m_ElectricEngine;

        public ElectricCar(string i_Lisence) : base(i_Lisence)
        {
            m_ElectricEngine = new ElectricEngine(k_MaxBatteryTime);
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = base.BuildVehicleInputsList();
            ElectricEngine.updateVehicleInputsList(vehicleInputsList);

            return vehicleInputsList;
        }

        public override Dictionary<string, string> BuildVehicleDetailsDictionary()
        {
            Dictionary<string, string> vehicleDetails = base.BuildVehicleDetailsDictionary();
            m_ElectricEngine.UpdateVehicleDetailsDictionary(vehicleDetails);

            return vehicleDetails;
        }

        public ElectricEngine ElectricEngine
        {
            get
            {
                return this.m_ElectricEngine;
            }
            set
            {
                this.m_ElectricEngine = value;
            }
        }

        public void SetEngine(string i_RemainingBatteryTime)
        {
            float remainingBatteryTime;

            if (float.TryParse(i_RemainingBatteryTime, out remainingBatteryTime) == false)
            {
                throw new FormatException("You must enter a number which represent the remaining bettary time.");
            }

            if (!(0 <= remainingBatteryTime && remainingBatteryTime <= m_ElectricEngine.MaxBatteryTime))
            {
                throw new ValueOutOfRangeException(0, m_ElectricEngine.MaxBatteryTime);
            }

            m_ElectricEngine.RemainingBatteryTime = remainingBatteryTime;

            this.PercentageOfRemainingEnergy = (m_ElectricEngine.RemainingBatteryTime / m_ElectricEngine.MaxBatteryTime) * 100;
        }// שיכפול קוד, לחשוב על פתרון
    }
}
