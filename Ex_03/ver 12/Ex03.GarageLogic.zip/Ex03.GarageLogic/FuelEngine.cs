﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelEngine
    {
        public enum eFuelType
        {
            Octan95 = 1,
            Octan96,
            Octan98,
            Soler
        }

        private readonly eFuelType r_FuelType;
        private float m_RemainingAmountOfFuel;
        private readonly float r_MaximumAmountOfFuel;

        public FuelEngine(float i_MaximumAmountOfFuel, eFuelType i_FuelType)
        {
            r_FuelType = i_FuelType;
            r_MaximumAmountOfFuel = i_MaximumAmountOfFuel;
        }

        public void RefuelEngine(float i_AmountOfFuel, eFuelType i_FuelType)
        {
            if (r_FuelType != i_FuelType)
            {
                throw new ArgumentException("Error - You entered a wrong fuel type.");
            }

            if (!((0 <= i_AmountOfFuel) && (i_AmountOfFuel <= r_MaximumAmountOfFuel - RemainingAmountOfFuel)))
            {
                throw new ValueOutOfRangeException(0, r_MaximumAmountOfFuel - RemainingAmountOfFuel);
            }

            m_RemainingAmountOfFuel += i_AmountOfFuel;
        }

        internal static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("the current amount of fuel:");
        }

        public void UpdateVehicleDetailsDictionary(Dictionary<string, string> vehicleDetails)
        {
            vehicleDetails.Add("The fuel type:", r_FuelType.ToString());
            vehicleDetails.Add("The remaining amount of fuel:", m_RemainingAmountOfFuel.ToString());
            vehicleDetails.Add("The maximum amount of fuel:", r_MaximumAmountOfFuel.ToString());
        }

        public float RemainingAmountOfFuel
        {
            set
            {
                m_RemainingAmountOfFuel = value;
            }
            get
            {
                return m_RemainingAmountOfFuel;
            }
        }

        public float MaximumAmountOfFuel
        {
            get
            {
                return r_MaximumAmountOfFuel;
            }
        }

        public static void isValidFuelTypePick(eFuelType i_FuelType)
        {
            if (!(Enum.IsDefined(typeof(eFuelType), i_FuelType)))
            {
                throw new ValueOutOfRangeException(1, NumOfFuelType());
            }
        }

        public static int NumOfFuelType()
        {
            return Enum.GetNames(typeof(eFuelType)).Length;
        }
    }
}
