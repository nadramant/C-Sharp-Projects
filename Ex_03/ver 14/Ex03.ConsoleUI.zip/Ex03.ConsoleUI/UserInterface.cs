﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Ex03.GarageLogic;

namespace Ex03.ConsoleUI
{
    internal class UserInterface
    {
        private Garage m_Garage; 

        public void Run()
        {
            m_Garage = new Garage();
            bool keepRunning = true;
            string userChoice;
            int choice;

            userChoice = getFirstChoice();

            while (keepRunning)
            {
                switch (userChoice)
                {
                    case "1":
                        insertVehicle();
                        break;
            
                    case "2":
                        viewListOfLicenseNumbers();
                        break;

                    case "3":
                        changeVehicleStatusInGarage();
                        break;

                    case "4":
                        inflateToMax();
                        break;

                    case "5":
                        refuelVehicle();
                        break;

                    case "6":
                        rechargeVehicle();
                        break;

                    case "7":
                        printVehicleDetails();
                        break;

                    case "8":
                        Console.WriteLine("Have a nice day :)");
                        keepRunning = false;
                        break;

                    default:
                        if(int.TryParse(userChoice, out choice))
                        {
                            Console.WriteLine("Invalid input. You must choose a number between 1-8.");
                        }
                        else
                        {
                            Console.WriteLine("Invalid input - You must choose a number.");
                        }

                        break;
                }

                if (keepRunning)
                {
                    printOptions();
                    userChoice = Console.ReadLine();
                }
            }
        }

        private string getFirstChoice()
        {
            int choice;
            bool validInput;
            string userChoice;

            printOptions();
            userChoice = Console.ReadLine();
            validInput = int.TryParse(userChoice, out choice);

            while (choice != 1 && choice != 8)
            {
                if (validInput)
                {
                    Console.WriteLine("There are no vehicles in the garage yet. You must choose 1 or 8.");
                }
                else
                {
                    Console.WriteLine("Invalid input - You must choose a number.");
                }

                userChoice = Console.ReadLine();
                validInput = int.TryParse(userChoice, out choice);
            }

            return userChoice;
        }

        private void printOptions()
        {
            Console.WriteLine(@"
Please choose one of the following options : 
1. Insert a new vehicle into the garage.
2. View the list of license numbers of the vehicles in the garage.
3. Modify a vehicle's status. 
4. Inflate the air of the wheels of the vehicles to the maximum.
5. Refuel a fuel-driven vehicle.
6. Recharge electric vehicle.
7. View full vehicle data by license number.
8. Quit program.
");
        }

        private void insertVehicle()
        {
            VehiclesCreator.eVehicleType vehicleType = getTypeFromUser();
            string licenseNumber = getLicenseFromUser();
            Vehicle newVehicle; 

            if (m_Garage.IsVehicleExistInGarage(licenseNumber, out newVehicle))
            {
                Console.WriteLine("This vehicle is already exist in the garage.");
                m_Garage[newVehicle, Garage.eCarDetails.CarStatusInGarage] = Garage.eCarStatusInGarage.InRepair;
            }
            else
            {
                newVehicle = VehiclesCreator.CreateVehicle(vehicleType, licenseNumber);
                insertDetailsToNewVehicle(newVehicle);
                insertVehicleToGarage(newVehicle);
                Console.WriteLine("The vehicle was successfully put into the garage.");
            }
        }

        private VehiclesCreator.eVehicleType getTypeFromUser()
        {
            List<string> vehicleTypesArray = VehiclesCreator.GetTypes();
            int i = 1;

            Console.WriteLine(@"
Please insert the type of the vehicle that you want to add.");

            foreach (string vechileType in vehicleTypesArray)
            {
                Console.WriteLine("{0}. {1}", i, vechileType);
                i++;
            }

            Console.WriteLine();

            bool validChoice = false;
            VehiclesCreator.eVehicleType vehicleType = (VehiclesCreator.eVehicleType)0;

            while (!validChoice)
            {
                try
                {
                    vehicleType = (VehiclesCreator.eVehicleType)int.Parse(Console.ReadLine());
                    VehiclesCreator.IsValidVehiclePick(vehicleType);

                    validChoice = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"Invalid Input. Please enter an integer.");
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(@"Invalid Input. You must enter a number between {0}-{1}.", ex.MinValue, ex.MaxValue);
                }
            }

            return vehicleType;
        }

        private string getLicenseFromUser()
        {
            bool validChoice = false;
            string licenseInput = null;

            Console.WriteLine(@"
Please enter the license number of the vehicle:");

            while (!validChoice)
            {
                try
                {
                    licenseInput = Console.ReadLine();
                    Vehicle.CheckLicenseLength(licenseInput);
                    Vehicle.CheckLicenseLetters(licenseInput);

                    validChoice = true;
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine("{0}Invalid Input. License number must be with {1} letters.", Environment.NewLine, ex.MaxValue);
                }
                catch (FormatException)
                {
                    Console.WriteLine("{0}Invalid Input. The license consists only upper cases lettes and digits.", Environment.NewLine);
                }
            }

            return licenseInput;
        }

        private void insertVehicleToGarage(Vehicle newVehicle)
        {
            bool isValidInput = false;
            while (!isValidInput)
            {
                try
                {
                    Console.WriteLine("Please enter the name of the owner:");
                    string nameOfOwner = Console.ReadLine();
                    Console.WriteLine("Please enter the phone number of the owner:");
                    m_Garage.AddVehicleToGarage(newVehicle, nameOfOwner, Console.ReadLine());
                    isValidInput = true;
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("{0}", ex.Message);
                }
            }
        }

        private void insertDetailsToNewVehicle(Vehicle i_NewVehicle)
        {
            List<string> vechileInputsList = i_NewVehicle.BuildVehicleInputsList();
            Type typeOfObject = i_NewVehicle.GetType();
            MethodInfo[] allMethodsOfObj = typeOfObject.GetMethods();
            Array.Reverse(allMethodsOfObj);
            int i = 0;

            foreach (MethodInfo method in allMethodsOfObj)
            {
                if (isSetMethod(method))
                {
                    bool isValidInputToMethod = false;
                    ParameterInfo[] allParams = method.GetParameters();

                    while (!isValidInputToMethod)
                    {
                        isValidInputToMethod = useSetMethod(i_NewVehicle, method, vechileInputsList, allParams, ref i);
                    }
                }
            }
        }

        private bool useSetMethod(Vehicle i_NewVehicle, MethodInfo i_Method, List<string> i_VechileInputsList, ParameterInfo[] i_AllParams, ref int io_Index)
        {
            bool isValidInput = false;
            int j = io_Index;

            try
            {
                List<object> setMethodInputsList = new List<object>();

                foreach (ParameterInfo param in i_AllParams)
                {
                    Console.WriteLine("Please enter {0}", i_VechileInputsList[io_Index]);
                    setMethodInputsList.Add(Console.ReadLine());
                    io_Index++;
                }

                i_Method.Invoke(i_NewVehicle, setMethodInputsList.ToArray());
                isValidInput = true;
            }
            catch (TargetInvocationException ex)
            {
                if (ex.InnerException is ValueOutOfRangeException)
                {
                    ValueOutOfRangeException innerException = ex.InnerException as ValueOutOfRangeException;
                    Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", innerException.MinValue, innerException.MaxValue, Environment.NewLine));
                }
                else if (ex.InnerException is FormatException)
                {
                    FormatException innerException = ex.InnerException as FormatException;
                    Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                }
                else if (ex.InnerException is ArgumentException)
                {
                    ArgumentException innerException = ex.InnerException as ArgumentException;
                    Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                }

                io_Index = j;
            }

            return isValidInput;
        }

        private bool isSetMethod(MethodInfo i_Method)
        {
            string methodName = i_Method.Name;

            return methodName.Contains("Set");
        }

        private void viewListOfLicenseNumbers()
        {
            int choice = 0;
            bool isValidInput = false;

            Console.WriteLine(@"Please choose which license numbers would you like to see:
1.Vehicles in repair
2.Repaired vehicles
3.Paied vehicles
4.All vehicles in garage");

            while (!isValidInput)
            {
                if (int.TryParse(Console.ReadLine(), out choice) && (choice >= 1 && choice <= 4))
                {
                    isValidInput = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. You must enter a number between 1-4.");
                }
            }

            List<string> listOfLicenseNumsOfVehicles = m_Garage.GetListOfVehiclesLicenseNumber((Garage.eCarStatusInGarage)choice);
            printVehicleLicenseList(listOfLicenseNumsOfVehicles);
        }

        private void printVehicleLicenseList(List<string> i_ListOfLicenseNumsOfVehicles)
        {
            if (i_ListOfLicenseNumsOfVehicles.Count == 0)
            {
                Console.WriteLine("There are no vehicles in this status at the garage.");
            }
            else
            {
                Console.WriteLine("There are {0} license numbers of the category that you chose : ", i_ListOfLicenseNumsOfVehicles.Count);

                int i = 1;

                foreach (string currLisenceNum in i_ListOfLicenseNumsOfVehicles)
                {
                    Console.WriteLine("{0} : {1}", i, currLisenceNum);
                    i++;
                }
            }
        }

        private void changeVehicleStatusInGarage()
        {
            string chosenLisenceNumber;
            bool isValidinput = false;

            while (!isValidinput)
            {
                try
                {
                    Vehicle vehicleToChange;

                    chosenLisenceNumber = getLicenseFromUser();
                    m_Garage.GetVehicleInGarage(chosenLisenceNumber, out vehicleToChange);

                    Console.WriteLine(@"Please select the new vehicle status from the following:
1.In repair
2.Repaired
3.Paied");
                    m_Garage.ChangeVehicleStatusInGarage(vehicleToChange, Garage.GetChosenStatus(Console.ReadLine()));
                    isValidinput = true;
                    Console.WriteLine("The status of the vehicle was changed successfully");
                }
                catch (FormatException ex) //למה צריך את זה? ההודעה המוצגת פה מוצגת גם באקספשן הרגיל. לא ראיתי שמתישהו הגענו לאקספשן הזה 
                {
                    Console.WriteLine(ex.Message);
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", ex.MinValue, ex.MaxValue, Environment.NewLine));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("{0}", ex.Message);
                }
            }
        }

        private void inflateToMax()
        {
            Vehicle vehicle;
            bool isValidInput = false;
            string lisenceNum;

            while (!isValidInput)
            {
                try
                {
                    lisenceNum = getLicenseFromUser();
                    m_Garage.GetVehicleInGarage(lisenceNum, out vehicle);
                    vehicle.InflateWheelsToMax();
                    Console.WriteLine("The wheels were inflated to maximum successfully.");
                    isValidInput = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void refuelVehicle()
        {
            string lisenceNum;
            Vehicle vehicleToRefuel;
            bool isValidInput = false;

            while (!isValidInput)
            {
                try
                {
                    lisenceNum = getLicenseFromUser();
                    m_Garage.GetVehicleInGarage(lisenceNum, out vehicleToRefuel);

                    Type typeOfObject = vehicleToRefuel.GetType();
                    MethodInfo[] allMethodsfObj = typeOfObject.GetMethods();

                    foreach (MethodInfo method in allMethodsfObj)
                    {
                        if (method.Name.Contains("RefuelEngine"))
                        {
                            useMethodToRefuel(method, vehicleToRefuel);
                            isValidInput = true;
                            break;
                        }
                    }

                    if (!isValidInput)
                    {
                        Console.WriteLine("This vehicle is an electric vehicle. You can't refuel it. Returning to main menu.");
                        break;
                    }
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", ex.MinValue, ex.MaxValue, Environment.NewLine));
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input.{0}", Environment.NewLine);
                }
                catch (TargetInvocationException ex)
                {
                    if (ex.InnerException is ValueOutOfRangeException)
                    {
                        ValueOutOfRangeException innerException = ex.InnerException as ValueOutOfRangeException;
                        Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", innerException.MinValue, innerException.MaxValue, Environment.NewLine));
                    }
                    else if (ex.InnerException is ArgumentException)
                    {
                        ArgumentException innerException = ex.InnerException as ArgumentException;
                        Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("{0}", ex.Message, Environment.NewLine);
                }
            }
        }

        private void useMethodToRefuel(MethodInfo i_RefuelMethod, Vehicle i_VehicleToRefuel)
        {
            Console.WriteLine(@"Please enter fuel type of vehicle : 
1. Octan95.
2. Octan96.
3. Octan98.
4. Soler.");
            FuelEngine.eFuelType fuelType = (FuelEngine.eFuelType)int.Parse(Console.ReadLine());
            FuelEngine.IsValidFuelTypePick(fuelType);

            Console.WriteLine(@"Please enter amount of fuel to refuel");
            float amountOfFuel = float.Parse(Console.ReadLine());

            i_RefuelMethod.Invoke(i_VehicleToRefuel, new object[] { amountOfFuel, fuelType });
            Console.WriteLine(@"The vehicle was successfully refueled.");
        }

        private void rechargeVehicle()
        {
            string lisenceNum;
            Vehicle vehicleToRecharge;
            bool isValidInput = false;

            while (!isValidInput)
            {
                try
                {
                    lisenceNum = getLicenseFromUser();
                    m_Garage.GetVehicleInGarage(lisenceNum, out vehicleToRecharge);

                    Type typeOfObject = vehicleToRecharge.GetType();
                    MethodInfo[] allMethodsfObj = typeOfObject.GetMethods();

                    foreach (MethodInfo method in allMethodsfObj)
                    {
                        if (method.Name.Contains("RechargeEngine"))
                        {
                            useMethodToRecharge(method, vehicleToRecharge);
                            isValidInput = true;
                            break;
                        }
                    }

                    if (!isValidInput)
                    {
                        Console.WriteLine("This vehicle is not electric. You can't recharge it. Returning to main menu.");
                        break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input.{0}", Environment.NewLine);
                }
                catch (TargetInvocationException ex)
                {
                    if (ex.InnerException is ValueOutOfRangeException)
                    {
                        ValueOutOfRangeException innerException = ex.InnerException as ValueOutOfRangeException;
                        Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", innerException.MinValue, innerException.MaxValue, Environment.NewLine));
                    }
                    else if (ex.InnerException is ArgumentException)
                    {
                        ArgumentException innerException = ex.InnerException as ArgumentException;
                        Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("{0}", ex.Message, Environment.NewLine);
                }
            }
        }

        private void useMethodToRecharge(MethodInfo i_RechargeMethod, Vehicle i_VehicleToRecharge)
        {
            Console.WriteLine(@"Please enter the amount you want to recharge.");
            float amountToRecharge = float.Parse(Console.ReadLine());

            i_RechargeMethod.Invoke(i_VehicleToRecharge, new object[] { amountToRecharge });
            Console.WriteLine(@"The vehicle was successfully recharged.");
        }

        private void printVehicleDetails()
        {
            string chosenLisenceNumber;
            Vehicle vehicleToPrint = null;
            bool isValidinput = false;

            while(!isValidinput)
            {
                try
                {
                    chosenLisenceNumber = getLicenseFromUser();
                    m_Garage.GetVehicleInGarage(chosenLisenceNumber, out vehicleToPrint);
                    isValidinput = true;
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            Dictionary<string, string> vehicleDetails = vehicleToPrint.BuildVehicleDetailsDictionary();
            m_Garage.UpdateVehicleDetails(vehicleDetails, vehicleToPrint);

            Console.WriteLine("These are the details of the vehicle:");
            foreach (KeyValuePair<string, string> currPair in vehicleDetails)
            {
                Console.WriteLine("{0}{1} {2}", Environment.NewLine, currPair.Key, currPair.Value);
            }     
        }
    }
}
