﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricEngine
    {
        private readonly float r_MaxBatteryTime;
        private float m_RemainingBatteryTime;

        public ElectricEngine(float i_MaxBatteryTime)
        {
            r_MaxBatteryTime = i_MaxBatteryTime;
        }

        public static void UpdateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("the remaining battery time:");
        }

        public void UpdateVehicleDetailsDictionary(Dictionary<string, string> vehicleDetails)
        {
            vehicleDetails.Add("The remaining battery time:", m_RemainingBatteryTime.ToString());
            vehicleDetails.Add("The maximum battery time:", r_MaxBatteryTime.ToString()); 
        }

        public float MaxBatteryTime
        {
            get
            {
                return r_MaxBatteryTime;
            }
        }

        public float RemainingBatteryTime
        {
            get
            {
                return m_RemainingBatteryTime;
            }

            set
            {
                m_RemainingBatteryTime = value;
            }
        }

        public void RechargeEngine(float i_AmountToRecharge)
        {
            if (!((i_AmountToRecharge >= 0) && (i_AmountToRecharge <= r_MaxBatteryTime - m_RemainingBatteryTime)))
            {
                throw new ValueOutOfRangeException(0, r_MaxBatteryTime - m_RemainingBatteryTime);
            }

            m_RemainingBatteryTime += i_AmountToRecharge;
        }
    }
}
