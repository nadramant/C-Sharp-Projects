﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelCar : Car
    {
        protected const FuelEngine.eFuelType k_FuelType = FuelEngine.eFuelType.Octan96;
        protected const float k_MaximumAmountOfFuel = 60;
        protected FuelEngine m_FuelEngine;

        public FuelCar(string i_Lisence) : base(i_Lisence)
        {
            m_FuelEngine = new FuelEngine(k_MaximumAmountOfFuel, k_FuelType);
        }

        public FuelEngine FuelEngine
        {
            get
            {
                return m_FuelEngine;
            }
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleDictionary = base.BuildVehicleInputsList();
            FuelEngine.UpdateVehicleInputsList(vehicleDictionary);

            return vehicleDictionary;
        }

        public override Dictionary<string, string> BuildVehicleDetailsDictionary()
        {
            Dictionary<string, string> vehicleDetails = base.BuildVehicleDetailsDictionary();
            m_FuelEngine.UpdateVehicleDetailsDictionary(vehicleDetails);

            return vehicleDetails;
        }

        public void SetEngine(string i_RemainingAmountOfFuel)
        {
            float remainingAmountOfFuel;

            if (float.TryParse(i_RemainingAmountOfFuel, out remainingAmountOfFuel) == false)
            {
                throw new FormatException("You must enter a number to the current amount of fuel.");
            }

            if (!(remainingAmountOfFuel >= 0 && remainingAmountOfFuel <= m_FuelEngine.MaximumAmountOfFuel))
            {
                throw new ValueOutOfRangeException(0, m_FuelEngine.MaximumAmountOfFuel);
            }

            m_FuelEngine.RemainingAmountOfFuel = remainingAmountOfFuel;

            this.PercentageOfRemainingEnergy = (m_FuelEngine.RemainingAmountOfFuel / m_FuelEngine.MaximumAmountOfFuel) * 100;
        }

        public void RefuelEngine(float i_AmountOfFuel, FuelEngine.eFuelType i_ChosenFuelType)
        {
            m_FuelEngine.RefuelEngine(i_AmountOfFuel, i_ChosenFuelType);
            this.PercentageOfRemainingEnergy = (m_FuelEngine.RemainingAmountOfFuel / m_FuelEngine.MaximumAmountOfFuel) * 100;
        }
    }
}
