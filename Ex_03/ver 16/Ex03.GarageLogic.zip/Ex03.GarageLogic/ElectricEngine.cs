﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricEngine
    {
        private readonly float r_MaxBatteryTime;
        private float m_RemainingBatteryTime;

        public ElectricEngine(float i_MaxBatteryTime)
        {
            r_MaxBatteryTime = i_MaxBatteryTime;
        }

        public void UpdateEngine(string i_RemainingBatteryTime)
        {
            float remainingAmountOfFuel;

            if (float.TryParse(i_RemainingBatteryTime, out remainingAmountOfFuel) == false)
            {
                throw new FormatException("You must enter a number to the current amount of fuel.");
            }

            if (!(remainingAmountOfFuel >= 0 && remainingAmountOfFuel <= r_MaxBatteryTime))
            {
                throw new ValueOutOfRangeException(0, r_MaxBatteryTime);
            }

            m_RemainingBatteryTime = remainingAmountOfFuel;
        }

        public static void UpdateVehicleInputsList(List<string> i_VehicleInputsList)
        {
            i_VehicleInputsList.Add("the remaining battery time:");
        }

        public void UpdateVehicleDetailsDictionary(Dictionary<string, string> i_VehicleDetails)
        {
            i_VehicleDetails.Add("The remaining battery time:", m_RemainingBatteryTime.ToString());
            i_VehicleDetails.Add("The maximum battery time:", r_MaxBatteryTime.ToString()); 
        }

        public float MaxBatteryTime
        {
            get
            {
                return r_MaxBatteryTime;
            }
        }

        public float RemainingBatteryTime
        {
            get
            {
                return m_RemainingBatteryTime;
            }

            set
            {
                m_RemainingBatteryTime = value;
            }
        }

        public void RechargeEngine(float i_AmountToRecharge)
        {
            if (!((i_AmountToRecharge >= 0) && (i_AmountToRecharge <= r_MaxBatteryTime - m_RemainingBatteryTime)))
            {
                throw new ValueOutOfRangeException(0, r_MaxBatteryTime - m_RemainingBatteryTime);
            }

            m_RemainingBatteryTime += i_AmountToRecharge;
        }
    }
}
