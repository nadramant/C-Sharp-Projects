﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelEngine
    {
        public enum eFuelType
        {
            Octan95 = 1,
            Octan96,
            Octan98,
            Soler
        }

        private readonly eFuelType r_FuelType;
        private readonly float r_MaximumAmountOfFuel;
        private float m_RemainingAmountOfFuel;

        public FuelEngine(float i_MaximumAmountOfFuel, eFuelType i_FuelType)
        {
            r_FuelType = i_FuelType;
            r_MaximumAmountOfFuel = i_MaximumAmountOfFuel;
        }

        public static void IsValidFuelTypePick(eFuelType i_FuelType)
        {
            if (!Enum.IsDefined(typeof(eFuelType), i_FuelType))
            {
                throw new ValueOutOfRangeException(1, NumOfFuelType());
            }
        }

        public static int NumOfFuelType()
        {
            return Enum.GetNames(typeof(eFuelType)).Length;
        }

        public static void UpdateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("the current amount of fuel:");
        }

        public void UpdateEngine(string i_RemainingAmountOfFuel)
        {
            float remainingAmountOfFuel;

            if (float.TryParse(i_RemainingAmountOfFuel, out remainingAmountOfFuel) == false)
            {
                throw new FormatException("You must enter a number to the current amount of fuel.");
            }

            if (!(remainingAmountOfFuel >= 0 && remainingAmountOfFuel <= r_MaximumAmountOfFuel))
            {
                throw new ValueOutOfRangeException(0, r_MaximumAmountOfFuel);
            }

            m_RemainingAmountOfFuel = remainingAmountOfFuel;
        }

        public void RefuelEngine(float i_AmountOfFuel, eFuelType i_FuelType)
        {
            if (r_FuelType != i_FuelType)
            {
                throw new ArgumentException("Error - You entered a wrong fuel type.");
            }

            if (!((i_AmountOfFuel >= 0) && (i_AmountOfFuel <= r_MaximumAmountOfFuel - RemainingAmountOfFuel)))
            {
                throw new ValueOutOfRangeException(0, r_MaximumAmountOfFuel - RemainingAmountOfFuel);
            }

            m_RemainingAmountOfFuel += i_AmountOfFuel;
        }

        public void UpdateVehicleDetailsDictionary(Dictionary<string, string> i_VehicleDetails)
        {
            i_VehicleDetails.Add("The fuel type:", r_FuelType.ToString());
            i_VehicleDetails.Add("The remaining amount of fuel:", m_RemainingAmountOfFuel.ToString());
            i_VehicleDetails.Add("The maximum amount of fuel:", r_MaximumAmountOfFuel.ToString());
        }

        public float RemainingAmountOfFuel
        {
            get
            {
                return m_RemainingAmountOfFuel;
            }

            set
            {
                m_RemainingAmountOfFuel = value;
            }
        }

        public float MaximumAmountOfFuel
        {
            get
            {
                return r_MaximumAmountOfFuel;
            }
        }
    }
}
