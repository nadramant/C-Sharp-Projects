﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelMotorcycle : Motorcycle
    {
        protected const FuelEngine.eFuelType k_FuelType = FuelEngine.eFuelType.Octan95;
        protected const float k_MaximumAmountOfFuel = 7;
        protected FuelEngine m_FuelEngine;

        public FuelMotorcycle(string i_Lisence) : base(i_Lisence)
        {
            m_FuelEngine = new FuelEngine(k_MaximumAmountOfFuel, k_FuelType);
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = base.BuildVehicleInputsList();
            FuelEngine.UpdateVehicleInputsList(vehicleInputsList);

            return vehicleInputsList;
        }

        public override Dictionary<string, string> BuildVehicleDetailsDictionary()
        {
            Dictionary<string, string> vehicleDetails = base.BuildVehicleDetailsDictionary();
            m_FuelEngine.UpdateVehicleDetailsDictionary(vehicleDetails);

            return vehicleDetails;
        }

        public void SetEngine(string i_RemainingAmountOfFuel)
        {
            m_FuelEngine.UpdateEngine(i_RemainingAmountOfFuel);
            this.PercentageOfRemainingEnergy = (m_FuelEngine.RemainingAmountOfFuel / m_FuelEngine.MaximumAmountOfFuel) * 100;
        }

        public void RefuelEngine(float i_AmountOfFuel, FuelEngine.eFuelType i_ChosenFuelType)
        {
            m_FuelEngine.RefuelEngine(i_AmountOfFuel, i_ChosenFuelType);
            this.PercentageOfRemainingEnergy = (m_FuelEngine.RemainingAmountOfFuel / m_FuelEngine.MaximumAmountOfFuel) * 100;
        }
    }
}
