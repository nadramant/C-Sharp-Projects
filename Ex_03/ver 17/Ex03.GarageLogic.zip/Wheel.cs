﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Wheel
    {
        private readonly float r_MaxAirPressure;
        private string m_ManufacturerName;
        private float m_CurrentAirPressure;

        public Wheel(float i_MaxAirPressure)
        {
            r_MaxAirPressure = i_MaxAirPressure;
        }

        public static void UpdateVehicleInputsList(List<string> i_VehicleInputsList)
        {
            i_VehicleInputsList.Add("the manufacturer name of the wheels:");
            i_VehicleInputsList.Add("the current air pressure in wheels:");
        }

        public void InflateWheels(float i_AmountOfAirToAdd)
        {
            m_CurrentAirPressure += i_AmountOfAirToAdd;
        }

        public void UpdateVehicleDetailsDictionary(Dictionary<string, string> i_VehicleDetails)
        {
            i_VehicleDetails.Add("The manufacturer name of the wheels:", m_ManufacturerName);
            i_VehicleDetails.Add("The current air pressure in wheels:", m_CurrentAirPressure.ToString());
            i_VehicleDetails.Add("The maximum air pressure in wheels:", r_MaxAirPressure.ToString());
        }

        public float MaxAirPressure
        {
            get
            {
                return r_MaxAirPressure;
            }
        }

        public string ManufacturerName
        {
            get
            {
                return m_ManufacturerName;
            }

            set
            {
                m_ManufacturerName = value;
            }
        }

        public float CurrentAirPressure
        {
            get
            {
                return m_CurrentAirPressure;
            }

            set
            {
                m_CurrentAirPressure = value;
            }
        }
    }
}
