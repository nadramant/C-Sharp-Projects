﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex03.GarageLogic;

namespace Ex03.ConsoleUI
{
    internal class UserInterface
    {
        private Garage m_Garage; 

        public void Run()
        {
            bool keepRunning = true;

            while (keepRunning)
            {
                PrintOptions();
                string userChoice = Console.ReadLine();

                switch (userChoice)
                {
                    case "1":
                        InsertNewVehicle();
                        break;

                    case "2":
                        break;

                    case "3":
                        break;

                    case "4":
                        break;

                    case "5":
                        break;

                    case "6":
                        break;

                    case "7":
                        break;

                    case "8":
                        Console.WriteLine("Have a nice day :)");
                        keepRunning = false;
                        break;

                    default:
                        Console.WriteLine("Invalid input");
                        break;
                }
            }
        }

        public void PrintOptions()
        {
            Console.WriteLine(@"
Welcome to the Garage.
Please choose one of the following options : 
1. Insert a new vehicle into the garage.
2. View the list of license numbers of the vehicles in the garage.
3. Modify a vehicle's status. 
4. Inflate the air of the wheels of the vehicles to the maximum.
5. Refuel a fuel-driven vehicle.
6. Recharge electric vehicle.
7. View full vehicle data by license number.
8. Quit program.
");
        }

        public void InsertNewVehicle()
        {
            Vehicle.eVehicleType vehicleType = getTypeFromUser();
            string licenseNumber = getLicenseFromUser();
            Vehicle newVehicle = VehiclesCreator.CreateVehicle(vehicleType, licenseNumber);
            VehicleInGarage existedVehicle = null;

            if(m_Garage.IsVehicleExistInGarage(newVehicle, out existedVehicle))
            {
                Console.WriteLine(@"This vehicle is already exist in the garage.");
                existedVehicle.CarStatusInGarage = VehicleInGarage.eCarStatusInGarage.InRepair;
            }
            else
            {
                getCarModelName(newVehicle);
            }
        }

        private void getCarModelName(Vehicle i_Vehicle)
        {
            bool validModelName = false;

            while (!validModelName)
            {
                try
                {
                    i_Vehicle.ModelName = Console.ReadLine();
                    validModelName = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"
Invalid model name - you must enter digits or letters.
For an example : Hyundai i35");
                }
            }
        }

        private string getLicenseFromUser()
        {
            bool validChoice = false;
            string licenseInput = null;

            Console.WriteLine(@"Please enter the license number of the vehicle.");

            while (!validChoice)
            {
                try
                {
                    licenseInput = Console.ReadLine();
                    Vehicle.checkLicenseLength(licenseInput);
                    Vehicle.checkLicenseLetters(licenseInput);

                    validChoice = true;
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(@"
Invalid Input. License number must be with {0} letters.", ex.MaxValue);
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"
Invalid Input. The license consists only upper cases lettes and digits.");
                }
            }

            return licenseInput;
        }

        private Vehicle.eVehicleType getTypeFromUser()
        {
            Console.WriteLine(@"Please insert the type of the vehicle that you want to add.
1. Motorcycle
2. Car
3. Truck");

            bool validChoice = false;
            Vehicle.eVehicleType vehicleType = (Vehicle.eVehicleType)0; // need to think other solution - ASK LILAH

            while (!validChoice)
            {
                try
                {
                    vehicleType = (Vehicle.eVehicleType)int.Parse(Console.ReadLine());
                    Vehicle.isValidVehiclePick(vehicleType);

                    validChoice = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"Invalid Input. Please enter an integer.");
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(@"Invalid Input. Your must enter a number between {0}-{1}.", ex.MinValue, ex.MaxValue);
                }
            }
            return vehicleType;
        }
    }
}
