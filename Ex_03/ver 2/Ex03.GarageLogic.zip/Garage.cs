﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        private List<VehicleInGarage> m_Vehicles;

        public bool IsVehicleExistInGarage(Vehicle i_VehicleToCheck,out VehicleInGarage i_ExistedVehicle)
        {
            bool isVehicleExist = false;
            i_ExistedVehicle = null;

            foreach (VehicleInGarage currVehicleInGarage in m_Vehicles)
            {
                if(i_VehicleToCheck == currVehicleInGarage.Vehicle)
                {
                    isVehicleExist = true;
                    i_ExistedVehicle = currVehicleInGarage;
                }
            }

            return isVehicleExist;
        }
    }
}
