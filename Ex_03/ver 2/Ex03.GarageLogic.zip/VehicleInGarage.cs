﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class VehicleInGarage
    {
        public enum eCarStatusInGarage
        {
            InRepair, Repaired, Paied
        }

        private string m_NameOfOwner;
        private string m_PhoneNumberOfOwner;
        private eCarStatusInGarage m_CarStatusInGarage = eCarStatusInGarage.InRepair;
        private Vehicle m_VechileInGarage;

        public Vehicle Vehicle
        {
            get
            {
                return m_VechileInGarage;
            }
        }

        public eCarStatusInGarage CarStatusInGarage
        {
            get
            {
                return m_CarStatusInGarage;
            }
            set
            {
                m_CarStatusInGarage = value;
            }
        }

    }
}
