﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public static class VehiclesCreator
    {
        public static Vehicle CreateVehicle(Vehicle.eVehicleType i_VehicleType, string i_Lisence)
        {
            Vehicle vehicle;

            if (i_VehicleType == Vehicle.eVehicleType.Car)
            {
                vehicle = new Car(i_Lisence);
            }
            else if (i_VehicleType == Vehicle.eVehicleType.Motorcycle)
            {
                vehicle = new Motorcycle(i_Lisence);
            }
            else
            {
                vehicle = new Truck(i_Lisence);
            }

            return vehicle;
        }
    }
}