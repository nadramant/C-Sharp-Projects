﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricMotorcycle : Motorcycle
    {
        ElectricEngine engine;

        public ElectricMotorcycle(string i_Lisence) : base(i_Lisence)
        {
        }
    }
}
