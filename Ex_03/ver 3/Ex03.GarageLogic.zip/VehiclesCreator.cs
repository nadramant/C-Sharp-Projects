﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public static class VehiclesCreator
    {
        public static Vehicle CreateVehicle(Vehicle.eVehicleType i_VehicleType, string i_Lisence)
        {
            Vehicle vehicle;

            if (i_VehicleType == Vehicle.eVehicleType.ElectricCar)
            {
                vehicle = new ElectricCar(i_Lisence);
            }
            else if (i_VehicleType == Vehicle.eVehicleType.FuelCar)
            {
                vehicle = new FuelCar(i_Lisence);
            }
            else if (i_VehicleType == Vehicle.eVehicleType.ElectricMotorcycle)
            {
                vehicle = new ElectricMotorcycle(i_Lisence);
            }
            else if (i_VehicleType == Vehicle.eVehicleType.FuelMotorcycle)
            {
                vehicle = new FuelMotorcycle(i_Lisence);
            }
            else
            {
                vehicle = new Truck(i_Lisence);
            }

            return vehicle;
        }
    }
}