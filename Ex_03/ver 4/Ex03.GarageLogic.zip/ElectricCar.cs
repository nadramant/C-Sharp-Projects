﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ElectricCar : Car
    {
        ElectricEngine engine;

        public ElectricCar(string i_Lisence) : base(i_Lisence)
        {
        }

        public override Dictionary<string, string> BuildVehicleDictionary()
        {
            Dictionary<string, string> vehicleDictionary = base.BuildVehicleDictionary();
            ElectricEngine.updateVehicleDictionary(vehicleDictionary);

            return vehicleDictionary;
        }
    }
}
