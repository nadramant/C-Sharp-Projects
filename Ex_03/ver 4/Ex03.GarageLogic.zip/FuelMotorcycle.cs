﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class FuelMotorcycle : Motorcycle
    {
        FuelEngine engine;

        public FuelMotorcycle(string i_Lisence) : base(i_Lisence)
        {
        }

        public override Dictionary<string, string> BuildVehicleDictionary()
        {
            Dictionary<string, string> vehicleDictionary = base.BuildVehicleDictionary();
            FuelEngine.updateVehicleDictionary(vehicleDictionary);

            return vehicleDictionary;
        }
    }
}
