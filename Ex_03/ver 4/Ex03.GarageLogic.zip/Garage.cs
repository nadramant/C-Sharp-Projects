﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        public enum eCarDetails
        {
            NameOfOwner, HomeNumberOfOwner, CarStatusInGarage
        }

        public enum eCarStatusInGarage
        {
            InRepair, Repaired, Paied
        }

        public Dictionary<int, object[]> m_VehiclesInGarage = new Dictionary<int, object[]>();

        public object[] this[int vehicle]
        {
            get
            {
                return m_VehiclesInGarage[vehicle];
            }

            set
            {
                m_VehiclesInGarage[vehicle] = value;
            }
        }

        public object this[int vehicleKey, eCarDetails details]
        {
            get
            {
                return m_VehiclesInGarage[vehicleKey][(int)details];
            }
            set
            {
                m_VehiclesInGarage[vehicleKey][(int)details] = value;
            }
        }

        public bool IsVehicleExistInGarage(Vehicle i_VehicleToCheck)
        {
            bool isVehicleExist = false;

            if (m_VehiclesInGarage.Count != 0)
            {
                foreach (KeyValuePair<int, object[]> currVehicleInGarage in m_VehiclesInGarage)
                {
                    if (i_VehicleToCheck.GetHashCode() == currVehicleInGarage.Key)
                    {
                        isVehicleExist = true;
                    }
                }
            }

            return isVehicleExist;
        }
    }
}
