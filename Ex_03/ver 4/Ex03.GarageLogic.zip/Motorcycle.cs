﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Motorcycle : Vehicle
    {
        public enum eLicenseType
        {
            A, A1, AA, B
        }

        private eLicenseType m_LicenseType;
        private int m_EngineCapacity;

        public Motorcycle(string i_Lisence) : base(i_Lisence)
        {
        }

        public override Dictionary<string, string> BuildVehicleDictionary()
        {
            Dictionary<string, string> vehicleDictionary = base.BuildVehicleDictionary();

            vehicleDictionary.Add("License type",null);
            vehicleDictionary.Add("Engine capacity", null);

            return vehicleDictionary;
        }
    }
}
