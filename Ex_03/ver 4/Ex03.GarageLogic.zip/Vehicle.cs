﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Vehicle
    {

        protected const int k_NumOfLettersInLicense = 8;
        protected string m_ModelName;
        protected readonly string m_LicenseNumber;
        protected float m_PercentageOfRemainingEnergy = 0;
        protected List<Wheel> m_Wheels;

        protected Vehicle(string i_Lisence)
        {
            m_LicenseNumber = i_Lisence;
        }

        public string ModelName
        {
            get
            {
                return m_ModelName;
            }
            set
            {
                foreach(char ch in value)
                {
                    if (!(char.IsLetterOrDigit(ch)))
                    {
                        throw new FormatException();
                    }
                }

                m_ModelName = value;
            }
        }

        public int NumOfLettersInLicense
        {
            get
            {
                return k_NumOfLettersInLicense;
            }
        }

        public static void checkLicenseLength(string i_LicenseInput)
        {
            if (i_LicenseInput.Length != Vehicle.k_NumOfLettersInLicense)
            {
                throw new ValueOutOfRangeException(1f, Vehicle.k_NumOfLettersInLicense);
            }
        }

        public static void checkLicenseLetters(string i_String)
        {
            foreach (char ch in i_String)
            {
                if (!(char.IsUpper(ch) || char.IsDigit(ch)))
                {
                    throw new FormatException();
                }
            }
        }

        public override int GetHashCode()
        {
            return m_LicenseNumber.GetHashCode();
        }

        public static bool operator !=(Vehicle i_Vehicle1, Vehicle i_Vehicle2)
        {
            return !(i_Vehicle1 == i_Vehicle2);
        }

        public static bool operator ==(Vehicle i_Vehicle1, Vehicle i_Vehicle2)
        {
            return i_Vehicle1.Equals(i_Vehicle2);
        }

        public override bool Equals(object obj) 
        {
            Vehicle vehicleToCompare = obj as Vehicle;
            bool isEquals = false;

            if(vehicleToCompare != null)
            {
                if(vehicleToCompare.GetHashCode() == this.GetHashCode())
                {
                    isEquals = true;
                }
            }

            return isEquals;
        }

        public virtual Dictionary<string, string> BuildVehicleDictionary()
        {
            Dictionary<string, string> vehicleDictionary = new Dictionary<string, string>();

            vehicleDictionary.Add("Model Name", null);
            vehicleDictionary.Add("Percentage Of remaining energy", null);
            Wheel.updateVehicleDictionary(vehicleDictionary);

            return vehicleDictionary;
        }
    }
}
