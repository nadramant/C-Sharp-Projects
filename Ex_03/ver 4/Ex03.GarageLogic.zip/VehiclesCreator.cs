﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public static class VehiclesCreator
    {
        public enum eVehicleType
        {
            FuelCar=1 , ElectricCar, FuelMotorcycle, ElectricMotorcycle, Truck
        }

        public static Vehicle CreateVehicle(eVehicleType i_VehicleType, string i_Lisence)
        {
            Vehicle vehicle;

            if (i_VehicleType == eVehicleType.ElectricCar)
            {
                vehicle = new ElectricCar(i_Lisence);
            }
            else if (i_VehicleType == eVehicleType.FuelCar)
            {
                vehicle = new FuelCar(i_Lisence);
            }
            else if (i_VehicleType == eVehicleType.ElectricMotorcycle)
            {
                vehicle = new ElectricMotorcycle(i_Lisence);
            }
            else if (i_VehicleType == eVehicleType.FuelMotorcycle)
            {
                vehicle = new FuelMotorcycle(i_Lisence);
            }
            else
            {
                vehicle = new Truck(i_Lisence);
            }

            return vehicle;
        }

        public static void isValidVehiclePick(eVehicleType i_VehicleType)
        {
            if (!(Enum.IsDefined(typeof(eVehicleType), i_VehicleType)))
            {
                throw new ValueOutOfRangeException(1, NumOfVehicleTypes());
            }
        }

        public static int NumOfVehicleTypes()
        {
            return Enum.GetNames(typeof(eVehicleType)).Length;
        }

        public static List<string> getTypes()
        {
            List<string> arrOfTypes = new List<string>();

            arrOfTypes.Add("Regular car");
            arrOfTypes.Add("Electric car");
            arrOfTypes.Add("Regular motorcycle");
            arrOfTypes.Add("Electric motorcycle");
            arrOfTypes.Add("Truck");

            return arrOfTypes;
        }
    }
}