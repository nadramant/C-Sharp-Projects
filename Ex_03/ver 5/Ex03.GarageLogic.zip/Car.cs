﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Car : Vehicle
    {
        public enum eCarColor
        {
            Red, White, Black, Silver
        }

        public enum eNumOfDoors
        {
            twoDoors, ThreeDoors, FourDoors, FiveDoors
        }

        private eNumOfDoors m_NumOfDoors;
        private eCarColor m_CarColor;

        public Car(string i_Lisence) : base(i_Lisence)
        {
        }

        public override List<string> BuildVehicleDictionary()
        {
            List<string> vehicleDictionary = base.BuildVehicleDictionary();

            vehicleDictionary.Add("Num of doors");
            vehicleDictionary.Add("Car color");

            return vehicleDictionary;
        }
    }
}
