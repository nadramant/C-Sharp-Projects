﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Motorcycle : Vehicle
    {
        public enum eLicenseType
        {
            A, A1, AA, B
        }

        private eLicenseType m_LicenseType;
        private int m_EngineCapacity;

        public Motorcycle(string i_Lisence) : base(i_Lisence)
        {
        }

        public override List<string> BuildVehicleDictionary()
        {
            List<string> vehicleDictionary = base.BuildVehicleDictionary();

            vehicleDictionary.Add("License type");
            vehicleDictionary.Add("Engine capacity");

            return vehicleDictionary;
        }
    }
}
