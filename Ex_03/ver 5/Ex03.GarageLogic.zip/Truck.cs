﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class Truck : Vehicle
    {
        private bool m_TransportHazardousMaterials; 
        private float m_CargoCapacity;

        public Truck(string i_Lisence) : base(i_Lisence)
        {
        }

        public override List<string> BuildVehicleDictionary()
        {
            List<string> vehicleDictionary = base.BuildVehicleDictionary();

            vehicleDictionary.Add(" 1 if it transport hazardous materials. else, enter 0.");
            vehicleDictionary.Add("cargo capacity");

            return vehicleDictionary;
        }
    }
}
