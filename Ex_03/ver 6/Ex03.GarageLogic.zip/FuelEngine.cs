﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class FuelEngine
    {
        public enum eFuelType
        {
            Octan98,
            Octan96,
            Octan95,
            Soler
        }

        private eFuelType m_FuelTupe;
        private float m_CurrentAmountOfFuel;
        private float m_MaximumAmountOfFuel;

        public void Refuling(float i_AmountOfFuelToAdd, eFuelType i_FuelType)
        {

        }

        internal static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("fuel type");
            vehicleInputsList.Add("current amount of fuel");
            vehicleInputsList.Add("maximum amount of fuel");
        }
    }
}
