﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Wheel
    {
        private string m_ManufacturerName;
        private float m_CurrentAirPressure;
        private float m_MaxAirPressure;
        
        public void InflateWheels(float i_AmountOfAirToAdd)
        {

        }

        public static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("manufacturer name");
            vehicleInputsList.Add("current air pressure");
            vehicleInputsList.Add("cax air pressure");
        }
    }
}
