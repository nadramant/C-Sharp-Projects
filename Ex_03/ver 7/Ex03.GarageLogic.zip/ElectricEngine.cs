﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    class ElectricEngine
    {
        private float m_RemainingBatteryTime;
        private readonly float r_MaxBatteryTime;

        public ElectricEngine(float i_MaxBatteryTime)
        {
            r_MaxBatteryTime = i_MaxBatteryTime;
        }

        public void BatteryCharging(int i_TimeToAddToBattery)
        {

        }

        public static void updateVehicleInputsList(List<string> vehicleInputsList)
        {
            vehicleInputsList.Add("remaining battery time");
            vehicleInputsList.Add("max battery time");
        }

        public float MaxBatteryTime
        {
            get
            {
                return r_MaxBatteryTime;
            }
        }

        public float RemainingBatteryTime
        {
            set
            {
                m_RemainingBatteryTime = value;
            }
            get
            {
                return m_RemainingBatteryTime;
            }
        }


    }
}
