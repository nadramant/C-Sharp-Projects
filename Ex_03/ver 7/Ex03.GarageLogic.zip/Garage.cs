﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        public enum eCarDetails
        {
            NameOfOwner, HomeNumberOfOwner, CarStatusInGarage
        }

        public enum eCarStatusInGarage
        {
            InRepair, Repaired, Paied
        }

        public Dictionary<Vehicle, object[]> m_VehiclesInGarage = new Dictionary<Vehicle, object[]>();

        public object[] this[Vehicle vehicle]
        {
            get
            {
                return m_VehiclesInGarage[vehicle];
            }

            set
            {
                m_VehiclesInGarage[vehicle] = value;
            }
        }

        public object this[Vehicle vehicle, eCarDetails details]
        {
            get
            {
                return m_VehiclesInGarage[vehicle][(int)details];
            }
            set
            {
                m_VehiclesInGarage[vehicle][(int)details] = value;
            }
        }

        public bool IsVehicleExistInGarage(Vehicle i_VehicleToCheck)
        {
            bool isVehicleExist = false;

            if (m_VehiclesInGarage.Count != 0)
            {
                foreach (KeyValuePair<Vehicle, object[]> currPair in m_VehiclesInGarage)
                {
                    if (i_VehicleToCheck == currPair.Key)
                    {
                        isVehicleExist = true;
                    }
                }
            }

            return isVehicleExist;
        }

        public void addCarToGarage(Vehicle i_VehicleToAdd, string i_NameOfOwner, string i_HomeNumberOfOwner)
        {
            foreach (char ch in i_NameOfOwner)
            {
                if (!(char.IsLetter(ch) || Char.IsWhiteSpace(ch)))
                {
                    throw new FormatException("Name of owner must contain only letters and spaces.");
                }
            }

            foreach (char ch in i_HomeNumberOfOwner)
            {
                if (!(char.IsDigit(ch)))
                {
                    throw new FormatException("Phone number must contain only digits.");
                }
            }

            m_VehiclesInGarage.Add(i_VehicleToAdd,new object[] { i_NameOfOwner, i_HomeNumberOfOwner, eCarStatusInGarage.InRepair});
        }
    }
}
