﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Motorcycle : Vehicle
    {
        public enum eLicenseType
        {
            A, A1, AA, B
        }

        protected const int k_NumOfWheels = 2;
        protected const int k_MaxAirPressure = 30;
        private eLicenseType m_LicenseType;
        private int m_EngineCapacity;

        public Motorcycle(string i_Lisence) : base(i_Lisence, k_NumOfWheels, k_MaxAirPressure)
        {
        }

        public override List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = base.BuildVehicleInputsList();

            vehicleInputsList.Add("license type");
            vehicleInputsList.Add("engine capacity");

            return vehicleInputsList;
        }

        public void SetEngineCapacity(string i_EngineCapacity)
        {
            int engineCapacity;

            if (int.TryParse(i_EngineCapacity, out engineCapacity) == false)
            {
                throw new FormatException("You must enter an integer number to the engine capacity.");
            }

            if(engineCapacity < 0)
            {
                throw new ArgumentException("engine's capacity can not be negative.");
            }

            m_EngineCapacity = engineCapacity;
        }

        public void SetLicenseType(string i_LicenseType)
        {
            Dictionary<string, eLicenseType> licenseTypeDictionary = new Dictionary<string, eLicenseType>();

            licenseTypeDictionary.Add("A", eLicenseType.A);
            licenseTypeDictionary.Add("A1", eLicenseType.A1);
            licenseTypeDictionary.Add("AA", eLicenseType.AA);
            licenseTypeDictionary.Add("B", eLicenseType.B);

            if (!licenseTypeDictionary.ContainsKey(i_LicenseType))
            {
                throw new FormatException("you must choose one of 'A', 'A1', 'AA' or 'B' to the license type.");
            }

            m_LicenseType = licenseTypeDictionary[i_LicenseType];
        }
    }
}
