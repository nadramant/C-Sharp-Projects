﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public abstract class Vehicle
    {
        protected const int k_NumOfLettersInLicense = 8;
        protected string m_ModelName;
        protected readonly string m_LicenseNumber;
        protected float m_PercentageOfRemainingEnergy = 0; 
        protected List<Wheel> m_Wheels;

        public Vehicle(string i_Lisence, int i_NumOfWheels, float i_MaxAirPressure)
        {
            m_LicenseNumber = i_Lisence;
            m_Wheels = new List<Wheel>();

            for(int i =0;i< i_NumOfWheels;i++)
            {
                m_Wheels.Add(new Wheel(i_MaxAirPressure));
            }
        }

        public void SetListOfWheels(string i_ManufacturerName, string i_CurrentAirPressure) // maybe extract code to other method
        {
            foreach (char ch in i_ManufacturerName)
            {
                if (!(char.IsLetterOrDigit(ch) || Char.IsWhiteSpace(ch)))
                {
                    throw new FormatException("You must enter characters or digits to the manufacturer name.");
                }
            }

            float currAirPressureInput;
            if (float.TryParse(i_CurrentAirPressure, out currAirPressureInput) == false)
            {
                throw new FormatException("You must enter a number to the current air pressure.");
            }

            if (!(0 <= currAirPressureInput && currAirPressureInput <= m_Wheels[0].MaxAirPressure))
            {
                throw new ValueOutOfRangeException(0, m_Wheels[0].MaxAirPressure);
            }

            for (int i = 0; i < m_Wheels.Count; i++) //try to change to foreach
            {
                m_Wheels[i].ManufacturerName = i_ManufacturerName;
                m_Wheels[i].CurrentAirPressure = currAirPressureInput;
            }
        }

        public void SetModelName(string i_ModelName)
        {
            foreach (char ch in i_ModelName)
            {
                if (!(char.IsLetterOrDigit(ch) || Char.IsWhiteSpace(ch)))
                {
                    throw new FormatException("You must enter characters or digits to the model name.");
                }
            }

            this.ModelName = i_ModelName;
        }
        public string ModelName
        {
            get
            {
                return m_ModelName;
            }
            private set
            {
                m_ModelName = value;
            }
        }

        public float PercentageOfRemainingEnergy
        {
            get
            {
                return m_PercentageOfRemainingEnergy;
            }
            set
            {
                m_PercentageOfRemainingEnergy = value;
            }
        }

        public int NumOfLettersInLicense
        {
            get
            {
                return k_NumOfLettersInLicense;
            }
        }

        public static void checkLicenseLength(string i_LicenseInput)
        {
            if (i_LicenseInput.Length != Vehicle.k_NumOfLettersInLicense)
            {
                throw new ValueOutOfRangeException(1f, Vehicle.k_NumOfLettersInLicense);
            }
        }

        public static void checkLicenseLetters(string i_String)
        {
            foreach (char ch in i_String)
            {
                if (!(char.IsUpper(ch) || char.IsDigit(ch)))
                {
                    throw new FormatException();
                }
            }
        }

        public override int GetHashCode()
        {
            return m_LicenseNumber.GetHashCode();
        }

        public static bool operator !=(Vehicle i_Vehicle1, Vehicle i_Vehicle2)
        {
            return !(i_Vehicle1 == i_Vehicle2);
        }

        public static bool operator ==(Vehicle i_Vehicle1, Vehicle i_Vehicle2)
        {
            return i_Vehicle1.Equals(i_Vehicle2);
        }

        public override bool Equals(object obj) 
        {
            Vehicle vehicleToCompare = obj as Vehicle;
            bool isEquals = false;

            if (vehicleToCompare.GetHashCode() == this.GetHashCode())
            {
                isEquals = true;
            }

            return isEquals;
        }

        public virtual List<string> BuildVehicleInputsList()
        {
            List<string> vehicleInputsList = new List<string>();

            vehicleInputsList.Add("model Name");
            Wheel.updateVehicleInputsList(vehicleInputsList);

            return vehicleInputsList;
        }
    }
}
