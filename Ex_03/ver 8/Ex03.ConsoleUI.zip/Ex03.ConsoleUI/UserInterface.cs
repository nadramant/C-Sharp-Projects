﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex03.GarageLogic;
using System.Reflection;

namespace Ex03.ConsoleUI
{
    internal class UserInterface
    {
        private Garage m_Garage; 

        public void Run()
        {
            m_Garage = new Garage();
            bool keepRunning = true;

            while (keepRunning)
            {
                printOptions();
                string userChoice = Console.ReadLine();

                switch (userChoice)
                {
                    case "1":
                        insertVehicle();
                        break;
            
                    case "2":
                        presentAllVehicleLicense();
                        break;

                    case "3":
                        changeVehicleStatusInGarage();
                        break;

                    case "4":
                        break;

                    case "5":
                        break;

                    case "6":
                        break;

                    case "7":
                        break;

                    case "8":
                        Console.WriteLine("Have a nice day :)");
                        keepRunning = false;
                        break;

                    default:
                        Console.WriteLine("Invalid input");
                        break;
                }
            }
        }

        private void printOptions()
        {
            Console.WriteLine(@"
Welcome to the Garage.
Please choose one of the following options : 
1. Insert a new vehicle into the garage.
2. View the list of license numbers of the vehicles in the garage.
3. Modify a vehicle's status. 
4. Inflate the air of the wheels of the vehicles to the maximum.
5. Refuel a fuel-driven vehicle.
6. Recharge electric vehicle.
7. View full vehicle data by license number.
8. Quit program.
");
        }

        private void insertVehicle()
        {
            VehiclesCreator.eVehicleType vehicleType = getTypeFromUser();
            string licenseNumber = getLicenseFromUser();
            Vehicle newVehicle = VehiclesCreator.CreateVehicle(vehicleType, licenseNumber);


            if (m_Garage.IsVehicleExistInGarage(licenseNumber))
            {
                Console.WriteLine("This vehicle is already exist in the garage.");
                m_Garage[newVehicle, Garage.eCarDetails.CarStatusInGarage] = Garage.eCarStatusInGarage.InRepair;
            }
            else
            {
                insertDetailsToNewVehicle(newVehicle);
                insertVehicleToGarage(newVehicle);
                Console.WriteLine("The vehicle was successfully put into the garage.");
            }
        }

        private void insertVehicleToGarage(Vehicle newVehicle)
        {
            bool isValidInput = false;
            while (!isValidInput)
            {
                try
                {
                    Console.WriteLine("Please enter the name of the owner.");
                    string nameOfOwner = Console.ReadLine();
                    Console.WriteLine("Please enter the phone number of the owner");
                    m_Garage.AddCarToGarage(newVehicle, nameOfOwner, Console.ReadLine());
                    isValidInput = true;
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("{0}", ex.Message);
                }
            }
        }

        private void insertDetailsToNewVehicle(Vehicle i_NewVehicle)
        {
            List<string> vechileInputsList = i_NewVehicle.BuildVehicleInputsList();
            Type typeOfObject = i_NewVehicle.GetType();
            MethodInfo[] allMethodsOfObj = typeOfObject.GetMethods();
            Array.Reverse(allMethodsOfObj);
            int i = 0;

            foreach (MethodInfo method in allMethodsOfObj)
            {
                if (isSetMethod(method))
                {
                    bool isValidInput = false;
                    ParameterInfo[] allParams = method.GetParameters();

                    while (!isValidInput)
                    {
                        isValidInput = getMethodInputs(i_NewVehicle, method, vechileInputsList, allParams, ref i);
                    }
                }
            }
        }

        private bool getMethodInputs(Vehicle i_NewVehicle, MethodInfo i_Method, List<string> i_VechileInputsList, ParameterInfo[] i_AllParams, ref int io_Index)
        {
            bool isValidInput = false;
            int j = io_Index;

            try
            {
                List<object> setMethodInputsList = new List<object>();

                foreach (ParameterInfo param in i_AllParams)
                {
                    Console.WriteLine("Please enter {0}", i_VechileInputsList[io_Index]);
                    setMethodInputsList.Add(Console.ReadLine());
                    io_Index++;
                }

                i_Method.Invoke(i_NewVehicle, setMethodInputsList.ToArray());
                isValidInput = true;
            }
            catch (TargetInvocationException ex)
            {
                if (ex.InnerException is ValueOutOfRangeException)
                {
                    ValueOutOfRangeException innerException = ex.InnerException as ValueOutOfRangeException;
                    Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", innerException.MinValue, innerException.MaxValue, Environment.NewLine));
                }
                else if (ex.InnerException is FormatException)
                {
                    FormatException innerException = ex.InnerException as FormatException;
                    Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                }
                else if (ex.InnerException is ArgumentException)
                {
                    ArgumentException innerException = ex.InnerException as ArgumentException;
                    Console.WriteLine("{0}{1}", innerException.Message, Environment.NewLine);
                }
                io_Index = j;
            }

            return isValidInput;
        }

        private bool isSetMethod(MethodInfo i_Method)
        {
            string methodName = i_Method.Name;

            return (methodName.Contains("Set"));
        }

        private string getLicenseFromUser()
        {
            bool validChoice = false;
            string licenseInput = null;

            Console.WriteLine(@"Please enter the license number of the vehicle.");

            while (!validChoice)
            {
                try
                {
                    licenseInput = Console.ReadLine();
                    Vehicle.checkLicenseLength(licenseInput);
                    Vehicle.checkLicenseLetters(licenseInput);

                    validChoice = true;
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(@"
Invalid Input. License number must be with {0} letters.", ex.MaxValue);
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"
Invalid Input. The license consists only upper cases lettes and digits.");
                }
            }

            return licenseInput;
        }

        private VehiclesCreator.eVehicleType getTypeFromUser()
        {
            List<string> vehicleTypesArray = VehiclesCreator.getTypes();
            int i = 1;

            Console.WriteLine("Please insert the type of the vehicle that you want to add.");

            foreach(string vechileType in vehicleTypesArray)
            {
                Console.WriteLine("{0}. {1}", i, vechileType);
                i++;
            }

            bool validChoice = false;
            VehiclesCreator.eVehicleType vehicleType = (VehiclesCreator.eVehicleType)0; // need to think other solution - ASK LILAH

            while (!validChoice)
            {
                try
                {
                    vehicleType = (VehiclesCreator.eVehicleType)int.Parse(Console.ReadLine());
                    VehiclesCreator.isValidVehiclePick(vehicleType);

                    validChoice = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine(@"Invalid Input. Please enter an integer.");
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(@"Invalid Input. You must enter a number between {0}-{1}.", ex.MinValue, ex.MaxValue);
                }
            }

            return vehicleType;
        }

        private void presentAllVehicleLicense()
        {
            int choice = 0;
            bool isValidInput = false;

            Console.WriteLine(@"Please choose which license numbers you would like to view:
1.Vehicles in repair
2.Repaired vehickes
3.Paied vehicles
4.All vehicles in garage");

            while (!isValidInput)
            {
                if ((int.TryParse(Console.ReadLine(), out choice)) && (1 <= choice && choice <= 4))
                {
                    isValidInput = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. You must enter a number between 1-4");
                }

                List<string> licenseNumOfVehiclesInGarge = m_Garage.AllVehiclesInGarage(choice);
                printAllVehicleLicenseInGarge(licenseNumOfVehiclesInGarge);
            }

        }

        private void printAllVehicleLicenseInGarge(List<string> i_LicenseNumOfVehiclesInGarge)
        {
            if (i_LicenseNumOfVehiclesInGarge.Count == 0)
            {
                Console.WriteLine("There are no vehicles in this status at the garge");
            }
            else
            {
                foreach (string currLisenceNum in i_LicenseNumOfVehiclesInGarge)
                {
                    Console.WriteLine(currLisenceNum);
                }
            }
        }

        private void changeVehicleStatusInGarage()
        {
            string lisenceNumber;
            int newStatus;
            bool isValidinput = false;
            while (!isValidinput)
            {
                try
                {
                    if(m_Garage.m_VehiclesInGarage.Count==0)
                    {
                        Console.WriteLine("There are no vehicles in the garage yet");
                        break;
                    }
                    Console.WriteLine("Please enter a the lisence number of the vehicle that you want to change his status");
                    lisenceNumber = Console.ReadLine();

                    while (!(m_Garage.IsVehicleExistInGarage(lisenceNumber)))
                    {
                        Console.WriteLine(@"Error. This vehicle license number is not in the garage.
        Please enter the lisence number again");
                        lisenceNumber = Console.ReadLine();
                    }
                    Console.WriteLine(@"Please select the new vehicle status from the following:
1.In repair
2.Repaired 
3.Paied");
                    newStatus = getNewStatus();
                    checkValidRangeOfInput(newStatus);
                    m_Garage.ChangeVehicleStatusInGarage(lisenceNumber, newStatus);
                    isValidinput = true;
                }
                catch (FormatException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (ValueOutOfRangeException ex)
                {
                    Console.WriteLine(string.Format("You must enter a number between {0}-{1}{2}", ex.MinValue, ex.MaxValue, Environment.NewLine));
                }
            }
        }

        private void checkValidRangeOfInput(int choice)
        {
            int minVal, maxVal;

            m_Garage.RangeOfCarStatusInGarge(out minVal, out maxVal);
            if (choice < minVal || choice > maxVal)
            {
                throw new ValueOutOfRangeException(minVal, maxVal);
            }
        }

        private int getNewStatus()
        {
            int newStatus;

            if(!(int.TryParse(Console.ReadLine(),out newStatus)))
            {
                throw new FormatException("Invalid input.You must enter an intager.");
            }

            return newStatus;
        }
    }
}
