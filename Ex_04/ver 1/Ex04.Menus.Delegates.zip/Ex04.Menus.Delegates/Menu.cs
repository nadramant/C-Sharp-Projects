﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Delegates
{
    public static class Menu
    {
        private const int k_BackOrExitMenu = 0;

        public static void Show(List<MenuItem> i_MenuItems, string i_NameOfMenu)
        {
            bool continueLoop = true;

            while(continueLoop)
            {
                int i = 0;
                int chosenItem;

                Console.WriteLine("{0}{1}", i_NameOfMenu, Environment.NewLine);

                foreach(MenuItem item in i_MenuItems)
                {
                    Console.WriteLine("{0}. {1}.", i, item.NameOfOption);
                    i++;
                }

                Console.WriteLine();

                chosenItem = getChosenNumber(i - 1);
                Console.Clear();

                if(chosenItem == k_BackOrExitMenu)
                {
                    continueLoop = false;
                }
                else
                {
                    i_MenuItems[chosenItem].Clicked = true;
                }
            }
        }

        private static int getChosenNumber(int i_NumOfOptions)
        {
            bool validInput = false;
            int chosenOption = 0;

            Console.WriteLine("Please choose one of the options 1 - {0}, or press 0 to exit.", i_NumOfOptions);

            while(!validInput)
            {
                try
                {
                    chosenOption = int.Parse(Console.ReadLine());

                    if(!(chosenOption >= 0 && chosenOption <= i_NumOfOptions))
                    {
                        throw new ArgumentOutOfRangeException();
                    }

                    validInput = true;
                }
                catch
                {
                    Console.WriteLine("Invalid Input. You must enter an integer number between 0 - {0}.", i_NumOfOptions);
                }
            }

            return chosenOption;
        }
    }
}
