﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Delegates
{
    public class MenuItem
    {
        private readonly List<MenuItem> r_SubMenuItems = new List<MenuItem>();
        private string m_NameOfOption;
        private bool m_Clicked;

        public event Action<MenuItem> ItemClicked; // check if valid name

        public MenuItem(string i_NameOfOption)
        {
            m_NameOfOption = i_NameOfOption;
        }

        public void Add(MenuItem i_NewItem)
        {
            r_SubMenuItems.Add(i_NewItem);
        }

        public string NameOfOption
        {
            get
            {
                return m_NameOfOption;
            }

            set
            {
                m_NameOfOption = value;
            }
        }

        public bool Clicked 
        {
            get
            {
                return m_Clicked;
            }

            set
            {
                m_Clicked = value;
                if(value)
                {
                    OnClicked();
                }
            }
        }

        protected virtual void OnClicked()
        {
            if(ItemClicked != null)
            {
                ItemClicked.Invoke(this);
            }
            else
            {
                Menu.Show(r_SubMenuItems, m_NameOfOption);
            }
        }
    }
}
