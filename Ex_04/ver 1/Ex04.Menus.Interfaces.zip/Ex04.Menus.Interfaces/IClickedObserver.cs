﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    public interface IClickedObserver
    {
        void ReportClicked(string i_NameOfOption);
    }
}
