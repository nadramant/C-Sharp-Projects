﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    public class MenuItem
    {
        private readonly List<MenuItem> r_SubMenuItems = new List<MenuItem>();
        private readonly List<IClickedObserver> r_ClickedObservers = new List<IClickedObserver>();
        private string m_NameOfOption;
        private bool m_Clicked = false;

        public MenuItem(string i_NameOfOption)
        {
            m_NameOfOption = i_NameOfOption;
        }

        public void Add(MenuItem i_newItem)
        {
            r_SubMenuItems.Add(i_newItem);
        }

        public string NameOfOption
        {
            get
            {
                return m_NameOfOption;
            }

            set
            {
                m_NameOfOption = value;
            }
        }

        public bool Clicked
        {
            get
            {
                return m_Clicked;
            }

            set
            {
                m_Clicked = value;
                if (value)
                {
                    doWhenClicked();
                }
            }
        }

        private void doWhenClicked()
        {
            if (r_ClickedObservers.Count != 0)
            {
                notifyAllClickedObservers();
            }
            else
            {
                Menu.Show(r_SubMenuItems, m_NameOfOption);
            }
        }

        private void notifyAllClickedObservers()
        {
            foreach (IClickedObserver observer in r_ClickedObservers)
            {
                observer.ReportClicked(m_NameOfOption);
            }
        }

        public void AttachObserver(IClickedObserver i_ClickedObserver)
        {
            r_ClickedObservers.Add(i_ClickedObserver);
        }

        public void DetachObserver(IClickedObserver i_ClickedObserver)
        {
            r_ClickedObservers.Remove(i_ClickedObserver);
        }
    }
}
