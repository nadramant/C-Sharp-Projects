﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    class MainMenu : IClickedObserver
    {
        public string m_NameOfMenu;
        private readonly List<MenuItem> r_MenuItems = new List<MenuItem>();

        public void BuildMenu()
        {

        }

        public void Show()
        {

        }

        public void ReportClicked(MenuItem i_MenuItem)
        {
            throw new NotImplementedException();
        }
    }
}
