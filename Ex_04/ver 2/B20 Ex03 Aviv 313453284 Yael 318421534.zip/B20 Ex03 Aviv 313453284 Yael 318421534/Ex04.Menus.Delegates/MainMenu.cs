﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Delegates
{
    class MainMenu
    {
        public string m_NameOfMenu;
        private readonly List<MenuItem> r_MenuItems = new List<MenuItem>();

        public MainMenu(string i_NameOfMenu)
        { 
            m_NameOfMenu = i_NameOfMenu;
            MenuItem exitMenuItem = new MenuItem("Exit");
            exitMenuItem.ItemClicked += menuItem_WasClicked;
            r_MenuItems.Add(exitMenuItem);
        }

        public void Show()
        {

        }

        private void menuItem_WasClicked(MenuItem i_MenuItem)
        {

        }
    }
}
