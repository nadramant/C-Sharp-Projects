﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Delegates
{
    class MenuItem
    {
        private readonly List<MenuItem> r_MenuItems = new List<MenuItem>();
        private string m_NameOfOption;
        public event Action<MenuItem> ItemClicked;
        private bool m_Clicked = false;

        public MenuItem(string i_NameOfOption)
        {
            m_NameOfOption = i_NameOfOption;
        }

        public bool Clicked
        {
            get
            {
                return m_Clicked;
            }
            set
            {
                m_Clicked = value;
                if(value)
                {
                    OnClicked();
                }
            }
        }

        protected virtual void OnClicked()
        {
            if (ItemClicked != null)
            {
                ItemClicked.Invoke(this);
            }
        }

        public void AttachObserver()
        {
        }

        public void DetachObserver()
        {
        }
    }
}
