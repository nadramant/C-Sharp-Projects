﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    class MenuItem 
    {
        private readonly List<MenuItem> r_MenuItems = new List<MenuItem>();
        private readonly List<IClickedObserver> r_ClickedObservers = new List<IClickedObserver>();
        private string m_NameOfOption;
        private bool m_Clicked;


        public void AttachObserver(IClickedObserver i_ClickedObserver)
        {
            r_ClickedObservers.Add(i_ClickedObserver);
        }

        public void DetachObserver(IClickedObserver i_ClickedObserver)
        {
            r_ClickedObservers.Remove(i_ClickedObserver);
        }

        public bool Clicked
        {
            get
            {
                return m_Clicked;
            }
            set
            {
                m_Clicked = value;
                if (value)
                {
                    doWhenClicked();
                }
            }
        }

        private void doWhenClicked()
        {
            foreach (IClickedObserver observer in r_ClickedObservers)
            {
                observer.ReportClicked(this);
            }
        }
    }
}
