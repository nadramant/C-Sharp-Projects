﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    public class MainMenu
    {
        private readonly List<MenuItem> r_MenuItems = new List<MenuItem>();
        private string m_NameOfMenu;

        public MainMenu(string i_NameOfMenu)
        {
            m_NameOfMenu = i_NameOfMenu;
        }

        public void Add(List<MenuItem> i_ItemsToAddToMainMenu)
        {
            foreach (MenuItem item in i_ItemsToAddToMainMenu)
            {
                r_MenuItems.Add(item);
            }
        }

        public void Show()
        {
            Menu.Show(r_MenuItems, m_NameOfMenu);
        }
    }
}
