﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    public class InterfacesMenu : IClickedObserver
    {
        private MainMenu m_MainMenu = new MainMenu("Main Menu");

        internal void Show()
        {
            List<MenuItem> itemsToAdd = new List<MenuItem>();
            MenuItem currItem;

            itemsToAdd.Add(new MenuItem("Exit"));
            itemsToAdd.Add(new MenuItem("Version and Digits"));
            itemsToAdd[1].Add(new MenuItem("Back"));
            currItem = new MenuItem("Count Capitals");
            currItem.AttachObserver(this as IClickedObserver);
            itemsToAdd[1].Add(currItem);
            currItem = new MenuItem("Show Version");
            currItem.AttachObserver(this as IClickedObserver);
            itemsToAdd[1].Add(currItem);
            itemsToAdd.Add(new MenuItem("Show Date/Time"));
            itemsToAdd[2].Add(new MenuItem("Back"));
            currItem = new MenuItem("Show Time");
            currItem.AttachObserver(this as IClickedObserver);
            itemsToAdd[2].Add(currItem);
            currItem = new MenuItem("Show Date");
            currItem.AttachObserver(this as IClickedObserver);
            itemsToAdd[2].Add(currItem);

            m_MainMenu.Add(itemsToAdd);
            m_MainMenu.Show();
        }

        public void ReportClicked(string i_NameOfOption)
        {
            switch (i_NameOfOption)
            {
                case "Count Capitals":
                    MenuItem_CountCapitalsItemWasClicked(); 
                    break;
                case "Show Version":
                    MenuItem_ShowVersionItemWasClicked();
                    break;
                case "Show Time":
                    MenuItem_ShowTimeItemWasClicked();
                    break;
                case "Show Date":
                    MenuItem_ShowDateItemWasClicked();
                    break;
            }
        }

        public void MenuItem_CountCapitalsItemWasClicked() // check if need to change name in interfaces
        {
            Console.Clear();
            string stringInput;
            int numOfCapitalLetters = 0;

            Console.WriteLine("Please enter a sentence : ");
            stringInput = Console.ReadLine();

            foreach (char ch in stringInput)
            {
                if (char.IsUpper(ch))
                {
                    numOfCapitalLetters++;
                }
            }

            Console.WriteLine("{0}There are {1} capital letters in this sentence.{0}", Environment.NewLine, numOfCapitalLetters);
        }

        public void MenuItem_ShowVersionItemWasClicked()
        {
            Console.Clear();
            Console.WriteLine("Version: 20.2.4.30620{0}", Environment.NewLine);
        }

        public void MenuItem_ShowTimeItemWasClicked()
        {
            Console.Clear();
            DateTime currentTime = DateTime.Now;
            Console.WriteLine("The time right now is : {0}:{1}{2}", currentTime.Hour, currentTime.Minute, Environment.NewLine);
        }

        public void MenuItem_ShowDateItemWasClicked()
        {
            Console.Clear();
            DateTime currentDate = DateTime.Now;
            Console.WriteLine("Today's Date is : {0}.{1}.{2}{3}", currentDate.Day, currentDate.Month, currentDate.Year, Environment.NewLine);
        }
    }
}
