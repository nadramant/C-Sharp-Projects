﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex04.Menus;

namespace Ex04.Menus.Test
{
    public class Program
    {
        public static void Main()
        {
            DelegatesMenu delegatesMenu = new DelegatesMenu();
            InterfacesMenu interfacesMenu = new InterfacesMenu();

            delegatesMenu.Show();
            interfacesMenu.Show();
        }
    }
}